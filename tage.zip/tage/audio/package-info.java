/**
 * Wrapper for the audio package JOAL.
 *
 * @author Kenneth Barnett
 */
package tage.audio;