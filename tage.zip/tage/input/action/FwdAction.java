package tage.input.action;

import tage.GameObject;
import tage.physics.*;
import tage.input.action.AbstractInputAction;
import net.java.games.input.Event;
import org.joml.*;
import org.joml.Math;

import myGame.MyGame;

public class FwdAction extends AbstractInputAction {
    private MyGame game;

    public FwdAction(MyGame game) {
        this.game = game;
    }

    @Override
    public void performAction(float time, Event e) {
        float keyValue = e.getValue();
        if (Math.abs(keyValue) < 0.2) return;

        GameObject av = game.getAvatar();
        PhysicsObject po = av.getPhysicsObject();
        Vector3f fwd = av.getLocalForwardVector();

        // Get linear velocity as float array
        float[] linearVelocityArray = po.getLinearVelocity();

        // Convert float array to Vector3f
        Vector3f velocity = new Vector3f(linearVelocityArray[0], linearVelocityArray[1], linearVelocityArray[2]);

        // Calculate the force direction based on car's orientation
        Vector3f forceDirection = new Vector3f(fwd.x, 0.0f, fwd.z).normalize();

        // Adjust force magnitude based on the key press intensity
        float forceMagnitude = 10.0f * Math.abs(keyValue); // Adjust as needed

        // Calculate the desired velocity based on the force direction and magnitude
        Vector3f desiredVelocity = new Vector3f(forceDirection).mul(forceMagnitude);

        // Calculate the difference between current velocity and desired velocity
        Vector3f velocityDifference = new Vector3f(desiredVelocity).sub(velocity);

        // Apply a force proportional to the velocity difference to adjust the car's velocity
        po.applyForce(velocityDifference.x, 0.0f, velocityDifference.z, 0.0f, 0.0f, 0.0f);
    }
}
