package tage.input.action;

import tage.GameObject;
import tage.physics.*;
import tage.input.action.AbstractInputAction;
import net.java.games.input.Event;
import org.joml.*;

import myGame.MyGame;

public class TurnAction extends AbstractInputAction {
    private MyGame game;

    public TurnAction(MyGame game) {
        this.game = game;
    }

    @Override
    public void performAction(float time, Event e) {
        float keyValue = e.getValue();
        if (keyValue > -0.2 && keyValue < 0.2) return;

        GameObject av = game.getAvatar();
        PhysicsObject po = av.getPhysicsObject();
        float torqueAmount = 1.0f; // Adjust as needed

        if (keyValue <= -0.2) {
            po.applyTorque(0.0f, torqueAmount, 0.0f);
        } else {
            po.applyTorque(0.0f, -torqueAmount, 0.0f);
        }
    }
}
