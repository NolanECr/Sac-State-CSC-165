package myGame;

import tage.*;
import tage.audio.AudioResource;
import tage.audio.AudioResourceType;
import tage.audio.IAudioManager;
import tage.audio.Sound;
import tage.audio.SoundType;
import tage.shapes.*;

import tage.physics.PhysicsEngine;
import tage.physics.PhysicsObject;
import tage.physics.JBullet.*;

import com.bulletphysics.dynamics.RigidBody;
import com.bulletphysics.collision.dispatch.CollisionObject;

import java.lang.Math;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.UUID;

import java.net.InetAddress;

import java.net.UnknownHostException;
import net.java.games.input.*;
import net.java.games.input.Component.Identifier.*;
import tage.networking.IGameConnection.ProtocolType;


import javax.swing.*;
import javax.xml.crypto.dsig.Transform;

import org.joml.*;
import tage.input.*;
import tage.input.action.*;
import tage.input.InputManager;
import net.java.games.input.Component.Identifier.*;
public class MyGame extends VariableFrameRateGame
{
	private static Engine engine;
	private InputManager im;
	private GhostManager gm;
	private boolean paused=false;
	private double lastFrameTime, currFrameTime, elapsTime;

	private GameObject avatar, terr, person;
	private GameObject track;
	private ObjShape terrS;
	private AnimatedShape personS;
	private ObjShape carS;
	private ObjShape ghostS;
	private ObjShape trackS;
	private ObjShape tofuS;
	private TextureImage cartx, ghostT, tracktx, concrete, map, persontx, tofuTx;
	private int nightSky;
	private Light light1, light2;

	private IAudioManager audioMgr;
	private Sound runSound;
	private PhysicsEngine physicsEngine;
	private PhysicsObject box1P, box2P, box3P, planeP;
	private PhysicsObject centerWall, centerWall2, centerWall3, wallN, wallW, wallS, wallE, wallW2;
	private boolean running = true;
	private float vals[] = new float[16];

	private CameraOrbitController orbitController;

	private String serverAddress;
	private int serverPort;
	private ProtocolType serverProtocol;
	private ProtocolClient protClient;
	private boolean isClientConnected = false;

	public MyGame(String serverAddress, int serverPort, String protocol)
	{	super();
		gm = new GhostManager(this);
		this.serverAddress = serverAddress;
		this.serverPort = serverPort;
		if (protocol.toUpperCase().compareTo("TCP") == 0)
			this.serverProtocol = ProtocolType.TCP;
		else
			this.serverProtocol = ProtocolType.UDP;
	}

	public static void main(String[] args)
	{	MyGame game = new MyGame(args[0], Integer.parseInt(args[1]), args[2]);
		engine = new Engine(game);
		game.initializeSystem();
		game.game_loop();
	}

	@Override
	public void loadShapes()
	{	personS = new AnimatedShape("human_mesh.rkm", "human_skel.rks");
		personS.loadAnimation("HIT", "human_hit.rka");
		carS = new ImportedModel("RaceCar.obj");
		ghostS = new ImportedModel("RaceCar.obj");
	    trackS = new ImportedModel("track.obj");
		terrS = new TerrainPlane(1000);
		tofuS = new ImportedModel("tofu.obj");
	}

	@Override
	public void loadTextures()
	{	persontx = new TextureImage("Watercolor_Blue.png");
		cartx = new TextureImage("WhiteBake.png");
		ghostT = new TextureImage("BlackBake.png");
		tracktx = new TextureImage("track.png");
		concrete = new TextureImage("concrete.png");
		map = new TextureImage("map.jpg");
		tofuTx = new TextureImage("tofu.png");
	}

	@Override
	public void loadSkyBoxes()
	{ 
		nightSky = (engine.getSceneGraph()).loadCubeMap("nightSky");
		(engine.getSceneGraph()).setActiveSkyBoxTexture(nightSky);
		(engine.getSceneGraph()).setSkyBoxEnabled(true);
	}

	@Override
	public void buildObjects()
	{	Matrix4f initialTranslation, initialScale, initialRotation;

		avatar = new GameObject(GameObject.root(), carS, cartx);
		initialTranslation = (new Matrix4f()).translation(-74,0.5f,-79);
		initialScale = (new Matrix4f()).scaling(0.25f);
		avatar.setLocalTranslation(initialTranslation);
		avatar.setLocalScale(initialScale);

		//car2 = new GameObject(GameObject.root(), car2S, car2tx);
		//initialTranslation = (new Matrix4f()).translation(-77,0.5f,-79);
		//initialScale = (new Matrix4f()).scaling(0.25f);
		//car2.setLocalTranslation(initialTranslation);
		//car2.setLocalScale(initialScale);

		person = new GameObject(GameObject.root(), personS, persontx);
		initialTranslation = (new Matrix4f()).translation(-24,0.5f,-24);
		initialScale = (new Matrix4f()).scaling(0.35f);
		person.setLocalTranslation(initialTranslation);
		person.setLocalScale(initialScale);

		/*track = new GameObject(GameObject.root(), trackS, tracktx);
		initialTranslation = (new Matrix4f()).translation(0,0,0);
		initialScale = (new Matrix4f()).scaling(50.0f);
		track.setLocalTranslation(initialTranslation);
		track.setLocalScale(initialScale);*/

		terr = new GameObject(GameObject.root(), terrS, concrete);
		initialTranslation = (new Matrix4f()).translation(0f,0f,0f);
		terr.setLocalTranslation(initialTranslation);
		initialScale = (new Matrix4f()).scaling(100.0f, 15.0f, 100.0f);
		terr.setLocalScale(initialScale);
		terr.setHeightMap(map);

		tofu = new GameObject(GameObject.root(), tofuS, tofuTx);
		initialTranslation = (new Matrix4f()).translation(62.0f, 2.0f, 81.0f);
		tofu.setLocalTranslation(initialTranslation);

		terr.getRenderStates().setTiling(1);
		terr.getRenderStates().setTileFactor(1);

	}

	@Override
	public void initializeLights()
	{	Light.setGlobalAmbient(0.5f, 0.5f, 0.5f);
		light1 = new Light();
		light2 = new Light();
		light1.setLocation(new Vector3f(-75.0f, 5.0f, -72.0f));
		light2.setLocation(new Vector3f(62.0f, 5.0f, 81.0f));
		(engine.getSceneGraph()).addLight(light1);
		(engine.getSceneGraph()).addLight(light2);
	}

	public void loadSounds()
	{ 
		AudioResource resource1, resource2;
		audioMgr = engine.getAudioManager();
		resource1 = audioMgr.createAudioResource("assets/sounds/EuroBeat.wav", AudioResourceType.AUDIO_SAMPLE);
		runSound = new Sound(resource1, SoundType.SOUND_EFFECT, 50, true);
		runSound.initialize(audioMgr);
		runSound.setMaxDistance(10.0f);
		runSound.setMinDistance(0.5f);
		runSound.setRollOff(5.0f);
	}

	@Override
	public void initializeGame()
	{	
		im = engine.getInputManager();
		String gpName = im.getFirstGamepadName();
		
		Camera c = (engine.getRenderSystem().getViewport("MAIN").getCamera());
		orbitController = new CameraOrbitController(c, avatar, gpName, engine);
		lastFrameTime = System.currentTimeMillis();
		currFrameTime = System.currentTimeMillis();
		elapsTime = 0.0;
		(engine.getRenderSystem()).setWindowDimensions(1900,1000);
		
		FwdAction fwdAction = new FwdAction(this, protClient);
		BckAction bckAction = new BckAction(this);
		TurnAction turnAction = new TurnAction(this);
		TurnLeftAction turnLeftAction = new TurnLeftAction(this);
		TurnRightAction turnRightAction = new TurnRightAction(this);

		im.associateActionWithAllGamepads(net.java.games.input.Component.Identifier.Button._0, fwdAction, InputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		im.associateActionWithAllGamepads(net.java.games.input.Component.Identifier.Button._1, bckAction, InputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		im.associateActionWithAllGamepads(net.java.games.input.Component.Identifier.Axis.X, turnAction, InputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);

		im.associateActionWithAllKeyboards(net.java.games.input.Component.Identifier.Key.W, fwdAction, InputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		im.associateActionWithAllKeyboards(net.java.games.input.Component.Identifier.Key.S, bckAction, InputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		im.associateActionWithAllKeyboards(net.java.games.input.Component.Identifier.Key.A, turnLeftAction, InputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		im.associateActionWithAllKeyboards(net.java.games.input.Component.Identifier.Key.D, turnRightAction, InputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);

		runSound.setLocation(avatar.getWorldLocation());
		setEarParameters();
		runSound.play();

		// --- initialize physics system ---
		float[] gravity = {0f, -10f, 0f};
		physicsEngine = (engine.getSceneGraph()).getPhysicsEngine();
		physicsEngine.setGravity(gravity);
		// --- create physics world ---
		float mass = 0.5f;
		float up[ ] = {0,1,0};
		float radius = 0.75f;
		float height = 0.0f;
		double[ ] tempTransform;
		float[] size = {1,1,2};
		float[] sizeP = {2,2,2};

		Matrix4f translation = new Matrix4f(avatar.getLocalTranslation());
		tempTransform = toDoubleArray(translation.get(vals));
		box1P = (engine.getSceneGraph()).addPhysicsBox(mass, tempTransform, size);
		avatar.setPhysicsObject(box1P);

		//translation = new Matrix4f(car2.getLocalTranslation());
		//tempTransform = toDoubleArray(translation.get(vals));
		//box2P = (engine.getSceneGraph()).addPhysicsBox(mass, tempTransform, size);
		//car2.setPhysicsObject(box2P);

		translation = new Matrix4f(terr.getLocalTranslation());
		tempTransform = toDoubleArray(translation.get(vals));
		planeP = (engine.getSceneGraph()).addPhysicsStaticPlane(tempTransform, up, 0.0f);
		terr.setPhysicsObject(planeP);

		translation = new Matrix4f(person.getLocalTranslation());
		tempTransform = toDoubleArray(translation.get(vals));
		box3P = (engine.getSceneGraph()).addPhysicsBox(mass, tempTransform, sizeP);
		person.setPhysicsObject(box3P);

		float[] size2 = {48,2,48};
		float[] size3 = {90,2,22};
		float[] size4 = {69,2,18};
		float[] size5 = {30,2,198};
		float[] size6 = {120,2,30};
		float[] size7 = {100,2,18};
		float[] size8 = {13,2,150};
		float[] size9 = {46,2,130};

		mass = 20f;
		translation = (new Matrix4f()).translation(16f,0.5f,-30f);
		tempTransform = toDoubleArray(translation.get(vals));
		centerWall = (engine.getSceneGraph()).addPhysicsBox(mass, tempTransform, size2);

		translation = (new Matrix4f()).translation(6f,0.5f,34f);
		tempTransform = toDoubleArray(translation.get(vals));
		centerWall2 = (engine.getSceneGraph()).addPhysicsBox(mass, tempTransform, size3);

		translation = (new Matrix4f()).translation(30f,0.5f,67f);
		tempTransform = toDoubleArray(translation.get(vals));
		centerWall3 = (engine.getSceneGraph()).addPhysicsBox(mass, tempTransform, size4);

		translation = (new Matrix4f()).translation(84,0.5f,0);
		tempTransform = toDoubleArray(translation.get(vals));
		wallE = (engine.getSceneGraph()).addPhysicsBox(mass, tempTransform, size5);

		translation = (new Matrix4f()).translation(2f,0.5f,-86f);
		tempTransform = toDoubleArray(translation.get(vals));
		wallN = (engine.getSceneGraph()).addPhysicsBox(mass, tempTransform, size6);

		translation = (new Matrix4f()).translation(15f,0.5f,95f);
		tempTransform = toDoubleArray(translation.get(vals));
		wallS = (engine.getSceneGraph()).addPhysicsBox(mass, tempTransform, size7);

		translation = (new Matrix4f()).translation(-94f,0.5f,0f);
		tempTransform = toDoubleArray(translation.get(vals));
		wallW = (engine.getSceneGraph()).addPhysicsBox(mass, tempTransform, size8);

		translation = (new Matrix4f()).translation(-63f,0.5f,23f);
		tempTransform = toDoubleArray(translation.get(vals));
		wallW2 = (engine.getSceneGraph()).addPhysicsBox(mass, tempTransform, size9);

		engine.enableGraphicsWorldRender();
		engine.enablePhysicsWorldRender();
		setupNetworking();
	}

	public GameObject getAvatar() { return avatar; }

	private float[] toFloatArray(double[] arr)
	{ 
		if (arr == null) return null;
		int n = arr.length;
		float[] ret = new float[n];
		for (int i = 0; i < n; i++)
		{ 
			ret[i] = (float)arr[i];
		}
		return ret;
	}

	private double[] toDoubleArray(float[] arr)
	{ 
		if (arr == null) return null;
		int n = arr.length;
		double[] ret = new double[n];
		for (int i = 0; i < n; i++)
		{ 
			ret[i] = (double)arr[i];
		}
		return ret;
	}

	public void setEarParameters()
	{ 
		Camera camera = (engine.getRenderSystem()).getViewport("MAIN").getCamera();
		audioMgr.getEar().setLocation(avatar.getWorldLocation());
		audioMgr.getEar().setOrientation(camera.getN(), new Vector3f(0.0f, 1.0f, 0.0f));
	}

	private void checkForCollisions()
	{ 
		com.bulletphysics.dynamics.DynamicsWorld dynamicsWorld;
		com.bulletphysics.collision.broadphase.Dispatcher dispatcher;
		com.bulletphysics.collision.narrowphase.PersistentManifold manifold;
		com.bulletphysics.dynamics.RigidBody object1, object2;
		com.bulletphysics.collision.narrowphase.ManifoldPoint contactPoint;
		dynamicsWorld = ((JBulletPhysicsEngine)physicsEngine).getDynamicsWorld();
		dispatcher = dynamicsWorld.getDispatcher();
		int manifoldCount = dispatcher.getNumManifolds();
		for (int i=0; i<manifoldCount; i++)
		{ 
			manifold = dispatcher.getManifoldByIndexInternal(i);
			object1 = (com.bulletphysics.dynamics.RigidBody)manifold.getBody0();
			object2 = (com.bulletphysics.dynamics.RigidBody)manifold.getBody1();
			JBulletPhysicsObject obj1 = JBulletPhysicsObject.getJBulletPhysicsObject(object1);
			JBulletPhysicsObject obj2 = JBulletPhysicsObject.getJBulletPhysicsObject(object2);
			if (obj1 == box3P || obj2 == box3P) { 
				personS.playAnimation("HIT", 2f,AnimatedShape.EndType.LOOP, 0);
			}
			for (int j = 0; j < manifold.getNumContacts(); j++)
			{ 
				contactPoint = manifold.getContactPoint(j);
				/*if (contactPoint.getDistance() < 0.0f)
				{ 
					System.out.println("---- hit between " + obj1 + " and " + obj2);
					break;
				} */
			} 
		} 
	}

	@Override
	public void update()
	{	
		orbitController.updateCameraPosition();

		Vector3f loc = avatar.getWorldLocation();
		float height = terr.getHeight(loc.x(), loc.z());
		avatar.setLocalLocation(new Vector3f(loc.x(), height, loc.z()));

		im.update((float) elapsTime);

		runSound.setLocation(avatar.getWorldLocation());
		setEarParameters();

		personS.updateAnimation();
		protClient.sendMoveMessage(avatar.getWorldLocation());

		double time = System.currentTimeMillis();
		Matrix4f currentTranslation, currentRotation;
		double totalTime = System.currentTimeMillis() - currFrameTime;
		elapsTime = System.currentTimeMillis() - lastFrameTime;
		lastFrameTime = System.currentTimeMillis();
		double amt = elapsTime * 0.03;
		double amtt = totalTime * 0.001;
		// update physics
		if (running)
		{ 
			AxisAngle4f aa = new AxisAngle4f();
			Matrix4f mat = new Matrix4f();
			Matrix4f mat2 = new Matrix4f().identity();
			Matrix4f mat3 = new Matrix4f().identity();
			checkForCollisions();
			physicsEngine.update((float)elapsTime);
			
			for (GameObject go:engine.getSceneGraph().getGameObjects())
			{ 
				if (go.getPhysicsObject() != null)
				{ // set translation
					mat.set(toFloatArray(go.getPhysicsObject().getTransform()));
					mat2.set(3,0,mat.m30());
					mat2.set(3,1,mat.m31());
					mat2.set(3,2,mat.m32());
					go.setLocalTranslation(mat2);
					// set rotation
					mat.getRotation(aa);
					mat3.rotation(aa);
					go.setLocalRotation(mat3);
				} 
			} 
		} 

		int elapsTimeSec = Math.round((float)totalTime) / 1000;
		String elapsTimeStr = Integer.toString(elapsTimeSec);
		String dispStr1 = "Time = " + elapsTimeStr;
		String dispStr2 = "position = " + avatar.getWorldLocation();
		Vector3f hud1Color = new Vector3f(1,0,0);
		Vector3f hud2Color = new Vector3f(0,0,1);
		(engine.getHUDmanager()).setHUD1(dispStr1, hud1Color, 15, 15);
		(engine.getHUDmanager()).setHUD2(dispStr2, hud2Color, 500, 15);

		im.update((float)elapsTime);
		processNetworking((float)elapsTime);
	}

	//public GameObject getAvatar() { return avatar; }

	@Override
	public void keyPressed(KeyEvent e)
	{	Vector3f loc, fwd, up, right, newLocation;
		Camera cam;
		switch (e.getKeyCode())
		{	case KeyEvent.VK_W:
			{	Vector3f oldPosition = avatar.getWorldLocation();
				Vector4f fwdDirection = new Vector4f(0f,0f,1f,1f);
				fwdDirection.mul(avatar.getWorldRotation());
				fwdDirection.mul(0.05f);
				Vector3f newPosition = oldPosition.add(fwdDirection.x(), fwdDirection.y(), fwdDirection.z());
				avatar.setLocalLocation(newPosition);
				protClient.sendMoveMessage(avatar.getWorldLocation());
				break;
			}
			case KeyEvent.VK_SPACE:
			{	System.out.println("starting physics");
				running = !running;
				break;
			}
		}
		super.keyPressed(e);
	}
	public ObjShape getGhostShape() { return ghostS; }
	public TextureImage getGhostTexture() { return ghostT; }
	public GhostManager getGhostManager() { return gm; }
	public Engine getEngine() { return engine; }
	
	private void setupNetworking()
	{	isClientConnected = false;	
		try 
		{	protClient = new ProtocolClient(InetAddress.getByName(serverAddress), serverPort, serverProtocol, this);
		} 	catch (UnknownHostException e) 
		{	e.printStackTrace();
		}	catch (IOException e) 
		{	e.printStackTrace();
		}
		if (protClient == null)
		{	System.out.println("missing protocol host");
		}
		else
		{	// Send the initial join message with a unique identifier for this client
			System.out.println("sending join message to protocol host");
			protClient.sendJoinMessage();
		}
	}
	
	protected void processNetworking(float elapsTime)
	{	// Process packets received by the client from the server
		if (protClient != null)
			protClient.processPackets();
	}

	public Vector3f getPlayerPosition() { return avatar.getWorldLocation(); }

	public void setIsConnected(boolean value) { this.isClientConnected = value; }
	
	private class SendCloseConnectionPacketAction extends AbstractInputAction
	{	@Override
		public void performAction(float time, net.java.games.input.Event evt) 
		{	if(protClient != null && isClientConnected == true)
			{	protClient.sendByeMessage();
			}
		}
	}
}